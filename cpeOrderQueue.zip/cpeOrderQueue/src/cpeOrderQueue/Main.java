package cpeOrderQueue;
import java.util.Scanner;

public class Main {
	public static int orderMenu(int item){
		Menu menuItem = new Menu();
		Scanner choiceNumber = new Scanner(System.in);
		
		System.out.println("Greetings Customer!");
		System.out.println("Menu:");
		System.out.print("1.] Burger - P");
		System.out.println(menuItem.burger);
		System.out.print("2.] Spaghetti - P");
		System.out.println(menuItem.spaghetti);
		System.out.print("3.] Fries - P");
		System.out.println(menuItem.fries);
		System.out.print("4.] Chicken - P");
		System.out.println(menuItem.chicken);
		System.out.print("Enter the menu item number you want to order: ");
		int choice = choiceNumber.nextInt();
		
		switch(choice){
		case 1:
			System.out.println("Item: Burger");
			System.out.print("Price: P");
			System.out.println(menuItem.burger);
			break;
		case 2:
			System.out.println("Item: Spaghetti");
			System.out.print("Price: P");
			System.out.println(menuItem.spaghetti);
			break;
		case 3:
			System.out.println("Item: Fries");
			System.out.print("Price: P");
			System.out.print(menuItem.fries);
			break;
		case 4:
			System.out.println("Item: Chicken");
			System.out.print("Price: P");
			System.out.println(menuItem.chicken);
			break;
		default:
			System.out.print("Invalid Option");
			break;
		}
		
		choiceNumber.close();
		return 0;
	}
	
	public static void main(String[] args) {
		int item = 0;
		orderMenu(item);

	}
}
