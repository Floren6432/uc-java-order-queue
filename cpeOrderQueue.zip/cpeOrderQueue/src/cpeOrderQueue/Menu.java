package cpeOrderQueue;

public class Menu {
	public final int burger = 50, spaghetti = 70, fries = 40, chicken = 100;
}
