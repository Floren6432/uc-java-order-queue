/**
 * 
 */
/**
 * @author Floren Go
 *
 */
module cpeOrderQueue {
}